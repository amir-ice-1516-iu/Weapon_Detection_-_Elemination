#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb 20 12:49:23 2020

@author : Khondokar Amir Hossain
@contact: amirkhondokar@gmail.com
"""
import serial

class LaserCommand(object):
    def __init__(self):
        for i in range(3):    
            try:
                self.arduino = serial.Serial("/dev/ttyACM"+str(i), 9600,bytesize=serial.EIGHTBITS, timeout=1)
            except Exception as eSend:
                print(eSend)
    def send(self,data="Fire"):
        self.arduino.write(bytes(data, 'utf8'))
    
    def receive(self):
        if self.arduino.in_waiting >0:
            return self.arduino.readline().decode("utf-8")
        else:
            return "K"
        
if __name__=='__main__':
    Laser = LaserCommand()
    while(True):
        k = input()
        if k=="e":
            break
        Laser.send(k)