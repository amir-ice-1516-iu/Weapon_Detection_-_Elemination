'''
This script is to apply trained model to detect guns in a video clip
Author : Khondokar Amir Hossain
Contact: amirkhondokar@gmail.com
'''

import os
import numpy as np
import cv2
import requests
from laser import LaserCommand
import time
import threading
from pyaudio_wrapper.audio_data import WavFileAudioData

load = WavFileAudioData("gun-cocking.wav")
shot = WavFileAudioData("gun-gunshot.wav")
shell = WavFileAudioData("empty-bullet-shell-fall.wav") 

#import imutils
#import datetime
def Map_angle(x,k):
    return int((x*35.0)/k)
posX = 105
posY = 70
gun_cascade = cv2.CascadeClassifier('cascade.xml')
camera = cv2.VideoCapture(0)
Exit = False
# initialize the first frame in the video stream
firstFrame = None

# loop over the frames of the video

gun_exist = False

def gun_shot(URL,interval=1):
    global shot, shell,load, Exit
    if not Exit:
        try:
            os.system("wget --output-document=responseGunShot "+URL+"/shoot")
            with open("responseGunShot","r") as f:
                signal = f.readline()
                print(signal)
                if signal =="fire":
                    load.play()
                    shot.play()
                    shell.play()
                    print("Fire signal ?")
                    print(signal)
                    os.system("wget --output-document=response "+URL+"/Target")
                threading.Timer(interval, gun_shot, [URL,interval]).start()
        except Exception:
            print("Fire exception")
            #Exit = True
            
def write_X(URL,interval=3):
    global posX, Exit
    posX = 2*(posX//2)
    #print("Sending X = ", posX)
    try:
        os.system("wget --output-document=response "+URL+"/X/"+str(posX))
        with open("response", "r") as f:        
            status = f.readline()
            #print(status)
            if not Exit:
                threading.Timer(interval,write_X,[URL,interval]).start()
    except Exception:
        print("X sending exception")
        #Exit = True
        
def write_Y(URL, interval=3):
    global posY, Exit
    posY = 2*(posY//2)
    #print("Sending Y = ", posY)
    try:
        os.system("wget --output-document=response "+URL+"/Y/"+str(posY))
        with open("response", "r") as f:        
            status = f.readline()
            #print(status)
            if not Exit:
                threading.Timer(interval,write_Y,[URL,interval]).start()
    except Exception:
        print("X sending exception")
        #Exit = True

#Laser = LaserCommand()
#time.sleep(1)
print("Please type the url")
URL = input()
os.system("wget --output-document=response "+URL)
with open("response","r") as f:
    Res = f.readline()
os.system("wget --output-document=response "+URL+"/Target")
with open("response","r") as f:
    Res = f.readline()
    print(Res)
time.sleep(1.25)
write_X(URL,0.75)
time.sleep(0.15)
write_Y(URL,0.75)
time.sleep(0.15)
gun_shot(URL,0.75)
load.play()
#Exit = True
Previous_call = time.time()
print("starting")
while(cv2.waitKey(1) & 0xff != ord('q')):
    try:
        grabbed , frame = camera.read()
        if not grabbed:
            print("No video Found")
            break
    except Exception as eRead:
        print(eRead)
        break

    # resize the frame, convert it to grayscale, and blur it
    #frame = imutils.resize(frame, width=500)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    #gray = cv2.GaussianBlur(gray, (21, 21), 0)
    
    gun = gun_cascade.detectMultiScale(gray, 1.3, 7, minSize = (128, 128))
    
    if len(gun) > 0:
        gun_exist = True
        
    for (x,y,w,h) in gun:
        if w<=160 and h <=160:
            frame = cv2.rectangle(frame,(x,y),(x+w,y+h),(255,0,0),2)
            roi_gray = gray[y:y+h, x:x+w]
            roi_color = frame[y:y+h, x:x+w]
            #print(frame.shape)
            if time.time()-Previous_call>=1:
                posX = 105 - int(((x + (w/2))*40)/640)
                posY = 70 + int(((y + (h/2))*40)/480)
                Previous_call = time.time()
            break
    # if the first frame is None, initialize it
    if firstFrame is None:
        firstFrame = gray
        continue

    # draw the text and timestamp on the frame
    #cv2.putText(frame, datetime.datetime.now().strftime("%A %d %B %Y %I:%M:%S%p"),
    #                (10, frame.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 0, 255), 1)
    # show the frame and record if the user presses a key
    frame = cv2.resize(frame,(1024,720))
    cv2.imshow("Security Feed", frame)
    #time.sleep(0.01)

Exit=True
# cleanup the camera and close any open windows
camera.release()
cv2.destroyAllWindows()






