#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb 21 01:06:37 2020

@author : Khondokar Amir Hossain
@contact: amirkhondokar@gmail.com
"""

from pyaudio_wrapper.audio_data import WavFileAudioData

load = WavFileAudioData("gun-cocking.wav")
shot = WavFileAudioData("gun-gunshot.wav")
shell = WavFileAudioData("empty-bullet-shell-fall.wav") 
# Play the audio from 500 millisecond to 1500 millisecond.
load.play()
shot.play()
shell.play()