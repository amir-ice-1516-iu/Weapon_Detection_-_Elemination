#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb 21 00:52:36 2020

@author : khondokar amir hossain
@contact: amirkhondokar@gmail.com
"""

import speech_recognition as sr
r = sr.Recognizer()
with sr.Microphone() as source:
    print("Say Something")
    audio = r.listen(source)
    print(dir(audio))
    print("Time over")

try:
    print("Text :"+r.recognize_google(audio))
except :
    pass